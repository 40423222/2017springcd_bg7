from sympy import *
'''
已知四連桿四個關鍵點座標分別為 A (x1, y1), B (x2, y2), C (x3, y3) 與 D (x4, y4)
且 E (x5, y5) 點相關參考x 座標距離為 d5, 而 y座標距離為 d6, 以及輸入角度逆時鐘轉 t 度
以 (x1, y1), (x4, y4), d1, d2, d3, d5, d6 及 t 等 10 個參數作為輸入, 
求 E 點座標 (x5, y5)
假設 AB 連桿長度為 d1, BC 連桿長度為 d2, CD 連桿長度為 d3, AD 距離為 d4
'''
x1, x2, x3, x4, x5 = symbols('x1 x2 x3 x4 x5')
y1, y2, y3, y4, y5 = symbols('y1 y2 y3 y4 y5')
d1, d2, d3, d4, d5, d6, t, t3 = symbols('d1 d2 d3 d4 d5 d6 t t3')
ah, bh, aj, dj, bd, hj, dk, bk = symbols('ah bh aj dj bd hj dk bk')
# angle daj defined as daj
daj, adj, bad, bcd, bdc, bdk = symbols('daj adj bad bcd bdc bdk')
# degree factor
degree, pi = symbols('degree pi')
degree = pi/180.0
# 假設 B 點的絕對 y 座標方向投影點為 H
d1 = sqrt((x1-x2)**2+(y1-y2)**2)
#print(d1)
d2 = sqrt((x2-x3)**2+(y2-y3)**2)
d3 = sqrt((x3-x4)**2+(y3-y4)**2)
d4 = sqrt((x1-x4)**2+(y1-y4)**2)
ah = d1*cos(t)
bh = sqrt(d1**2 - ah**2)
aj = Abs(x4-x1)
dj = Abs(y4-y1)
dk = aj - ah
bk =  bh - dj
t3 = bdc + bdk
# for daj, dj**2 = d4**2+aj**2 -2*d4*aj*cos(daj)
pos = 1
if pos == 1:
    daj = solve(-dj**2+d4**2+aj**2 -2*d4*aj*cos(daj), daj)[0]
else:
    daj = solve(-dj**2+d4**2+aj**2 -2*d4*aj*cos(daj), daj)[1]
#print(daj)
# for adj, aj**2=d4**2+dj**2-2*d4*aj*cos(adj)
if pos == 1:
    adj = solve(-aj**2+d4**2+dj**2-2*d4*aj*cos(adj), adj)[0]
else:
    adj = solve(-aj**2+d4**2+dj**2-2*d4*aj*cos(adj), adj)[0]
#print(adj)
bad = t*degree - daj
# according triangle tad find bd
#bd**2 = d1**2+d4**2-2*d1*d4*cos(bad)
if pos == 1:
    bd = solve(-bd**2+d1**2+d4**2-2*d1*d4*cos(bad), bd)[0]
else:
    bd = solve(-bd**2+d1**2+d4**2-2*d1*d4*cos(bad), bd)[1]
print(bd)

if pos == 1:
    bcd = solve(-bd**2+d2**2+d3**2-2*d2*d3*cos(bcd), bcd)[0]
else:
    bcd = solve(-bd**2+d2**2+d3**2-2*d2*d3*cos(bcd), bcd)[1]

if pos == 1:
    bdk = solve(-bk**2+bd**2+dk**2-2*bd*dk*cos(bdk), bdk)[0]
else:
    bdk = solve(-bk**2+bd**2+dk**2-2*bd*dk*cos(bdk), bdk)[1]

if pos == 1:
    bdc = solve(-d2**2+d3**2+bd**2-2*d3*bd*cos(bdc), bdc)[0]
else:
    bdc = solve(-d2**2+d3**2+bd**2-2*d3*bd*cos(bdc), bdc)[1]
print(t3)